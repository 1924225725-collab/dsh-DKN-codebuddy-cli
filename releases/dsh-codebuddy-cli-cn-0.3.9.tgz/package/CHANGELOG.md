# 更新记录 / Changelog

历史版本现补齐 GitHub Releases，原安装包不变。0.2.10 仅为本地候选，改动合入 0.3.0，未单独公开发布。

Historical GitHub Releases are backfilled with the unchanged packages. The local 0.2.10 candidate is included in 0.3.0 and has no separate public release.

## 0.3.9 — 本地预览 / Local preview（2026-10-26）

- 新增安全结构诊断：图片流固定拒绝原因、阶段、帧序号与大小、init/result 计数、终止发起方及实际 close 观察事实；未知帧类别不记录原始名称。
- 原生结果区分 structured_output 字段缺失、null 与固定类型，补充固定 subtype 和错误提示类别／命中来源；不保存原始帧、stderr 或任意键名。
- 新事实贯通持久化、恢复、普通／详细导出、最近调用及配置页。旧记录没有的事实保持缺失；退出码仅在观察到 close 后记录。
- 取消与图片卸载单列统计并保留采集机会，卸载只记录所需数量。文字取消和输出超限及时结束；不新增自动重试或修复请求。
- 不调整既有国内 init／元数据接受范围，不套用国际状态机；唯一原生终态、显式错误／权限／工具协议拒绝、图片隐私和账号绑定规则保留。
- Validation: 59 targeted automated checks passed, plus two official CLI 2.174.0 synthetic text/image calls with persisted diagnostic facts. No actual DSH UI/business-tool acceptance or private-history replay. User CLI 2.175.0/2.176.0 failures remain unconfirmed; improved diagnostics do not establish their root cause or eliminate intermittent faults.
- Local preview only. No GitHub publication or running DSH/profile/network/authentication changes. Existing packages remain unchanged.

## 0.3.8 — 本地预览 / Local preview（2026-10-25）

- 明确区分 CLI 原生 StructuredOutput 与 DSH 工具提案：系统提示、响应 Schema 说明及完整历史末尾的提交规则共同约束，DSH 业务工具仍由 DSH 执行。
- 图片流收到完整的非 StructuredOutput 原生工具调用时，提前以 CLI_TOOL_PROTOCOL_ERROR 拦截，不执行或猜测恢复工具请求、不等待总超时。普通文字中的示例不会因此被当作工具调用。
- 识别 CLI 明确的原生工具不存在错误；修正含图片历史的超时提示，不再把超时归因为登录失效、图片过大或模型权限不足。
- Preserve native Schema validation, existing history/image budgets, account-bound routing and the single-result rule. Do not add automatic retries, CLI business tools or account/model fallback.
- Validation: 97 automated checks and 5 official CLI synthetic calls passed. The latter cover hy3 long image-history proposals and result summaries, a text-tool regression, and the installed bili_watch name/link schema with fabricated inputs and results. No real DSH business tool was executed, and no private conversation was replayed. A baseline synthetic call also passed, so this does not claim full reproduction or elimination of the original intermittent failure.
- This hardens an intermittent model/CLI protocol failure; it cannot guarantee every model always chooses the correct native output tool. Real DSH extension-tool acceptance remains a separate manual check. Local preview only; not published on GitHub.

## 0.3.7 — 本地预览 / Local preview（2026-10-25）

- 新增独立账号环境、手动选择、生成官方登录命令和移出列表。Windows / 官方 npm 版 CLI 2.174.0，首次逐个官方授权，不导入现有凭据。
- 每账号独立配置、用户目录及 AppData；清除竞争认证来源，禁用自动更新与用户/项目设置注入。默认登录模式保留旧行为。
- 模型 ID 绑定随机环境 ID，工具后续和图片继续使用原环境；不自动轮换、补号或回落其他账号。失效、移除、旧模型、目录异常和未核查 CLI 版本均明确阻止。
- 增加按环境区分的进程内调用统计及匿名诊断标识、配置页双语说明和使用指南。用量不冒充官方扣费或余额，移出条目保留本地官方登录数据。
- Add isolated official sign-in environments, manual selection and account-bound model IDs. Preserve existing tool/image protocols and default sign-in behavior. No automatic rotation or credential import.
- Version-guarded PowerShell launchers preserve empty arguments on Windows PowerShell 5.1. Competing credentials, settings injection, missing accounts and unknown CLI versions fail closed.
- Validation: 95 automated checks and 8 real official CLI configuration/version/preparation checks passed, including preserved 0.3.6 context/image safeguards. Real two-account sign-in, refresh, billing attribution and actual DSH UI acceptance remain unverified. **Not published on GitHub.**

## 0.3.6（本地候选 / Local candidate）

- 对 CLI 明确返回的 HTTP 400 上下文超限与 HTTP 402 余额不足使用独立错误码和固定说明，不暴露原始错误正文。
- 对累计超过 32,768 个字符的标准内联图片 data URI，在提交模型请求前拒绝，提示改用 DSH 图片附件；日志仅保留 URI 数量与字符数，不保存图片或 Base64。
- 明确标注模型目录中的上下文窗口是 CLI 元数据，不保证等于服务端单次请求的实际输入上限。
- 不自动截断或删除 DSH 历史，不把字符数冒充 Token 估算；原生图片附件与工具图片通道保持不变。
- Classify explicit CLI HTTP 400 context-limit and HTTP 402 insufficient-balance errors with fixed safe messages; do not expose raw error bodies.
- Block standard inline image data URIs exceeding 32,768 aggregate characters before submitting the model request. Keep only numeric URI count/character statistics, never image or Base64 content.
- Clarify that model-catalog context windows are CLI metadata and may differ from the service's actual per-request input limit.
- Do not truncate or delete DSH history or present character counts as token estimates. Preserve the native image attachment and tool-image paths.

## [0.3.5](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.5)

- 识别 CLI 已知 ECONNRESET 与 TLS 建连失败提示，使用固定 CLI_NETWORK_ERROR，覆盖空标准输出且退出码为 0 的情况。
- 保留诊断 ID、耗时、输出字节和退出码，不暴露原始标准错误、地址或凭据；文字与图片共用分类，不自动重试。
- 不改变合法结果、未知空输出、登录/权限分类、超时或工具行为；更新配置页与中英使用指南。
- Recognize fixed CLI connection-reset/TLS failures with CLI_NETWORK_ERROR, including empty stdout and exit 0. Keep safe diagnostics and identifiers without raw stderr or credentials.
- Cover text and image failures without retries, model switching, parser fallback or changes to valid results and existing authentication/permission handling.
- 验证 / Validation: 82 automated checks passed with synthetic failures and existing regression coverage. No live model call was made; network recovery is not claimed.

## [0.3.4](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.4)

- 接入 DSH 工具结果中的标准图片附件，覆盖桌面/窗口/区域/浏览器截图、图片读取及其他工具图片，不按工具名设置白名单。
- 保留工具调用 ID、失败标记、文字和图片次序；没有调用 ID 的工具图片明确拒绝。用户图和工具图共用预算与卸载，含图片失败不采集原文。
- 识别官方 CLI 的 error 帧，安全归类鉴权、本机权限或通用错误，不交付其后的结果；更新日志版本标记。
- 配置页和中英文档加入工具适配范围；原生音视频、二进制文档和模型原生图片生成未适配。
- Accept standard DSH tool image results without a tool-name allowlist. Preserve tool call identity, error flags, adjacent text and image order; reject detached tool images.
- Share upload/tool-image budgets, durable offloading and privacy protections. Classify CLI error frames safely and correct the log version marker. Add bilingual tool compatibility documentation and its settings link.
- 验证 / Validation: 79 automated checks and three official CLI 2.174.0 / deepseek-v4.1-flash calls passed with synthetic tool images. Attachment service was isolated; no real desktop was captured or actual business tool executed. Actual DSH capture-tool UI flows and all-model coverage remain unverified.

## [0.3.3](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.3)

- 修复 DSH 0.2.1-rc.3 对旧版精确 rc.2 依赖的兼容性拦截。engines.dsh 与六项 DSH peer 依赖均明确列出 0.2.1-rc.2、0.2.1-rc.3，不放宽到未经核查的未来版本。
- 对比六项官方 npm 发布包：LLM、附件、渲染、设置和本地化运行文件一致；插件管理页新增导航入口，不影响现有配置页注册。
- 模型、图片、工具、用量和日志运行代码不变；不需要版本豁免，不覆盖旧安装包。
- Fix DSH 0.2.1-rc.3 rejecting the previous exact rc.2 requirements. Declare both reviewed runtimes in engines.dsh and all six DSH peers without claiming future versions.
- Compare six official npm packages. The LLM, attachment, renderer, settings and locale runtime files are identical; the plugin-manager addition does not affect this adapter's configuration registration.
- Keep model/image/tool/usage/logging runtime code unchanged. No version exemption is required and old packages are preserved.
- 验证 / Validation: 74 existing automated checks and official DSH compatibility preflight checks. No new live model call or actual DSH upload-UI validation in this metadata-only update.

## [0.3.2](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.2)

- 新增用户图片提问与历史追问：从 DSH 附件服务读取图片，使用官方 stream-json 原生 image 输入，保留原生 Schema 输出。
- 模型目录增加图片能力标记，未知或未声明能力的路由不接收图片；纯文字调用保留原路径。
- 多图通过索引关联历史消息；最多保留 5 张请求图片，每张转换后 ≤2 MiB、最长边 ≤1920，Base64 合计 ≤8 MiB，文字与图片总请求 ≤20 MiB。超预算通过 DSH 的持久图片卸载机制处理，不静默丢图。
- 图片流支持总超时、取消、严格 JSONL 与唯一终态检查；业务工具仍由 DSH 执行。
- 含图片历史的调用禁用失败原文采集，普通日志仅记录图片数量与字节统计。更新中英配置说明、使用指南和安装教程。
- Add user image questions and history follow-ups through DSH attachments and official native image blocks in stream-json, retaining native Schema output.
- Show catalog-declared image capability; reject images for unknown/undeclared routes and preserve the existing text-only transport.
- Associate images with history by index. Retain up to 5 request images, each converted to ≤2 MiB and longest edge ≤1920; combined Base64 ≤8 MiB, total text/image request ≤20 MiB. Request durable DSH image offloading rather than silently dropping history.
- Bound image streams with cancellation, deadlines, strict JSONL and unique-terminal validation. DSH continues to execute business tools.
- Disable raw failure capture for calls containing image history. Basic logs retain counts/byte totals only. Update bilingual settings, guides and installation instructions.
- 验证 / Validation: This release passed 74 automated checks and six synthetic official CLI image calls through the new adapter: PNG single image, follow-up, two-image order, tool proposal, summary after a simulated tool result and a JPEG check. China-region live tests used deepseek-v4.1-flash and CLI 2.173.0 with an isolated attachment-service test double. No real DSH business tool ran; DSH upload-UI manual end-to-end validation and every-model coverage remain outstanding. Official structured processing may involve internal model turns; official usage applies.

## [0.3.1](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.1)

- 改用官方 --json-schema，只开放 StructuredOutput 输出工具，直接读取 structured_output 对象，退出普通文字 JSON 候选扫描路径。
- 原生结果缺失、字符串/包装结果、不合法字段或多个最终记录明确失败，不静默回退、不选择最后一份。
- 保留 DSH 工具名与对象参数检查；单一计划内的重复操作不删除，工具执行继续由 DSH 管理。
- 保留取消、总超时、日志隐私和诊断 ID；原生校验失败也保留进程统计。更新配置页及中英故障指南。
- 结构化处理允许有限 CLI 内部轮次；插件不额外启动 CLI 做修复，官方内部处理仍可能消耗多轮额度。
- Use official --json-schema with only the StructuredOutput output tool enabled; read the structured_output object instead of scanning prose for JSON candidates.
- Reject missing native output, string/wrapper envelopes, invalid fields and multiple final records without prose fallback or arbitrary last-result selection.
- Retain DSH tool-name/object-argument validation and repeated operations within one plan. DSH continues to execute business tools.
- Preserve cancellation, total deadlines, diagnostic IDs and log privacy. Native validation failures retain process diagnostics. Update bilingual in-settings and full troubleshooting guides.
- Allow bounded CLI internal turns for structured processing. The adapter starts no extra CLI repair process; official processing can still consume multiple internal model turns.
- 验证 / Validation: 60 automated checks and three synthetic official CLI calls through the new adapter passed. No real DSH business tool ran; not every model was tested.

## [0.3.0](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.3.0)

- 仅当多个完整协议对象交付的文字及有序工具名称/参数完全一致时，恢复为一份结果；不合并冲突计划，不删除同一计划中的重复工具。
- 合入 0.2.10 本地候选版的文字转义恢复：仅限完整对象、恰好 text 与空 toolCalls 两字段，不补全缺失结构、不恢复工具参数。
- 用户主动取消任务不再消耗“一次失败回复采集”；普通日志标记重复候选数量。
- 配置页增加中英故障处理指南，说明多结果冲突、长回复、工具已执行后的失败、字面转义和日志隐私。
- 加强单一最终结果及转义说明；保留全部既有结构、工具、鉴权和日志回归检查。
- Recover repeated complete envelopes only when their delivered text and ordered tool names/arguments are identical. Never merge conflicting plans or remove repeated calls within a plan.
- Include the unpublished 0.2.10 candidate: bounded text escape recovery only for complete objects containing exactly text and empty toolCalls; no invented structure or tool-argument repair.
- User cancellation preserves armed failure capture. Basic logs count duplicate candidates. Add bilingual in-settings troubleshooting and reinforce final-result/escaping instructions.
- Validation: 55 automated checks passed and two synthetic official CLI requests succeeded. Recovery boundaries are covered by deterministic tests; these checks do not guarantee every model reply or device.

## [0.2.9](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.9)

- 对括号完整、无协议字段且不含已声明工具名的损坏 JSON 示例，作为无工具文字交付；协议形状或未闭合内容仍拦截。
- Deliver balanced malformed JSON examples as plain text only when they have no protocol fields or declared tool names; reject protocol-shaped and incomplete content.

## [0.2.8](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.8)

- 完善普通文字、JSON 示例和方括号标记的无工具回退；保留未闭合尾部检查，不把截断内容当完整结果。
- 普通日志增加扫描完整性、字符串状态和容器深度，不记录正文。
- Improve text-only fallback for prose, examples and bracketed markers while retaining incomplete-tail rejection. Add content-free scan/string/depth diagnostics.

## [0.2.7](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.7)

- 修复 DSH 错误分类丢失；显示机器错误码和可关联日志的 diagnostic-id。
- 保留工具结果 isError，完善权限/先读后改说明；及时释放完成请求计数，拒绝空白无工具结果。
- Preserve DSH error codes and diagnostic IDs, tool-result isError flags, and permission/read-before-edit instructions. Release completed request counts promptly; reject blank tool-free results.

## [0.2.6](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.6)

- 识别标准错误中的固定鉴权/权限/限流提示，即使 stdout 为空且退出码为零，也不再一律误报 JSON 无效。
- 区分空输出与非 JSON，记录输出字节数、耗时和退出码；鉴权错误显示官方登录指引。
- Recognize fixed auth/permission/rate-limit notices, including empty stdout with zero exit status. Distinguish empty/non-JSON output, log numeric process diagnostics and show official sign-in guidance.

## [0.2.5](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.5)

- 增加本机持久化日志、查看/导出/清空与默认关闭的一次失败原文采集；普通导出不含原文，不自动上传。
- 逐个验证片段，允许唯一有效结果旁的明确无关完整示例；冲突与疑似工具片段继续拒绝。
- Add local persistent diagnostics, view/export/clear, and opt-in one-failure raw-result capture. Basic exports omit raw text; no automatic uploads. Validate fragments independently and accept a unique valid result beside clearly unrelated complete examples.

## [0.2.4](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.4)

- 支持明确的完整 JSON 包装、二次编码及纯文字/纯工具结构，增加不含正文的分类诊断和最近失败摘要。
- 补充长回复、结构异常及完整工具往返的自动回归；冲突/缺失结构不猜测、不自动重试。
- Recognize complete wrappers, encoded JSON and unambiguous text/tool-only structures. Add content-free diagnostics and regression coverage for long replies, malformed output and tool continuation, without guessing conflicts or missing content.

## [0.2.3](https://github.com/1924225725-collab/dsh-codebuddy-cli-cn/releases/tag/v0.2.3)

- 使用提示词描述输出协议并在本地验证，取消 CLI 原生 --json-schema 处理，不自动追加修复请求。
- Describe the response protocol in the prompt and validate locally instead of native --json-schema processing; no automatic repair request.

## 0.2.2

- 区分版本检查与模型请求；显示运行版本与超时诊断；超时及时返回。
- Distinguish executable checks from model calls; show running version and timeout diagnostics; settle deadlines promptly.

## 0.2.1

- 修复缓存重复计数；减少重复工具定义；区分累计与单次用量；按完整内容块返回。
- Fix duplicate cache accounting, remove duplicate tool definitions, separate cumulative and last-call usage, and return complete content blocks.

## 0.2.0

- 增加 ACP 模型/倍率同步、一键配置、官方登录命令和当前用户路径检测。
- Add ACP model/rate discovery, one-click setup, official sign-in commands and current-user path detection.

## 0.1.x

- 实现模型提供方、无头调用、配置页及 Windows 启动适配。
- Initial model provider, headless calls, settings page and Windows launch support.
